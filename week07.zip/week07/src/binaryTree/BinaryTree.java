package binaryTree;

public class BinaryTree<T extends Comparable<? super T>> implements BTree<T> {

	@Override
	public void insert(T value) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public T value() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BTree<T> left() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BTree<T> right() {
		// TODO Auto-generated method stub
		return null;
	}

}
