package errors;

public class RailwaySystemError extends Exception {
	public RailwaySystemError(String message) {
		super(message);
	}
}
