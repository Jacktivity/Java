package counter;

import java.util.HashSet;

public class ThreadHashSet<T extends Thread> extends HashSet<T> implements ThreadSet<T>{
}
